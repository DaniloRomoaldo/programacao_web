import { database } from "../knex/knexfile.js";


export function create(Newcurso){
}


export const findAll = () => {
}

export const findOne = (id) => {

    return {};
}

export const update = (id, Newcurso) => {
}

export const destroy = (id) => {
}
